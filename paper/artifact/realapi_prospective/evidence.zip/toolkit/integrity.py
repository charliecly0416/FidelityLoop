"""Portable file seals for preparation, immutable source, and return delivery."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(8*1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def inventory(root, *, excluded=()):
    root = Path(root).resolve()
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError("symlink in sealed material")
        rel = path.relative_to(root).as_posix()
        if path.is_file() and rel not in excluded:
            result[rel] = dict(bytes=path.stat().st_size, sha256=digest(path))
    return result


def seal(root, name="FILES_SHA256.json"):
    root = Path(root)
    result = inventory(root)
    if (root/name).exists():
        raise ValueError("seal already exists")
    with (root/name).open("x", encoding="utf-8") as target:
        json.dump(result, target, indent=2, sort_keys=True)
        target.write("\n")
    return digest(root/name)


def verify(root, name="FILES_SHA256.json"):
    root = Path(root)
    expected = json.loads((root/name).read_text())
    if inventory(root, excluded=(name,)) != expected:
        raise ValueError("file inventory/content differs from seal")
    return dict(status="PASS", files=len(expected), manifest_sha256=digest(root/name))


def pack(root, destination):
    root, destination = Path(root).resolve(), Path(destination).resolve()
    if destination.is_relative_to(root):
        raise ValueError("archive must be outside source root")
    verify(root)
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root).as_posix())
    return digest(destination)


def extract(archive, destination):
    destination = Path(destination)
    if destination.exists():
        raise ValueError("extraction requires a new directory")
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError("duplicate archive members")
        for item in z.infolist():
            p = PurePosixPath(item.filename)
            if (p.is_absolute() or ".." in p.parts or "\\" in item.filename
                    or ":" in item.filename or ((item.external_attr >> 16) & 0o170000) == 0o120000):
                raise ValueError("unsafe archive member")
        if z.testzip():
            raise ValueError("CRC failure")
        z.extractall(destination)
    return verify(destination)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=["seal", "verify", "pack", "extract"])
    p.add_argument("root", type=Path)
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    if args.action in ("pack", "extract") and args.output is None:
        p.error("--output required")
    result = {"seal": lambda: seal(args.root), "verify": lambda: verify(args.root),
              "pack": lambda: pack(args.root, args.output),
              "extract": lambda: extract(args.root, args.output)}[args.action]()
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
