"""Real-offload evidence helpers; no GPU launch on import."""
