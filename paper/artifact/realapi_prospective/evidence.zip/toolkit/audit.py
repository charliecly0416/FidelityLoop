"""Independent audit of normalized records, not a GPU execution engine."""
import argparse
import hashlib
import json
import math
from pathlib import Path

from .offload import canonical, completion_payload, validate_response


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(value):
    require(type(value) in (int, float) and math.isfinite(value), "nonfinite time")
    return value


def evaluate(data, *, physical=True):
    require(data["schema"] == "real-api-record-v1", "record schema")
    end = 2100.0
    inputs = data["inputs"]
    by_id = {r["request_id"]: r for r in inputs}
    require(len(inputs) == len(by_id), "duplicate input IDs")
    records = {r["request_id"]: r for r in data["requests"]}
    require(len(records) == len(data["requests"]) and set(records) == set(by_id),
            "every planned request must have exactly one terminal record")
    populations = {k: dict(arrivals=0, on_time=0, late=0, unfinished=0, errors=0)
                   for k in ("online", "offline")}
    api_count = api_ok = input_tokens = output_tokens = 0
    api_latencies = []
    for rid, source in by_id.items():
        kind = source["job_type"]
        require(kind in populations, "request class")
        arrival, deadline = number(source["arrival_s"]), number(source["deadline_s"])
        require(0 <= arrival < 1800 and deadline == arrival + (60 if kind == "online" else 300),
                "arrival/deadline changed")
        require(source["input_tokens"] == len(source["prompt_token_ids"]), "input token count")
        record = records[rid]
        route, dispatched, finished = (record[k] for k in ("route", "dispatched_at", "completed_at"))
        require(route in (None, "real_api", "local0", "local1"), "route")
        if dispatched is not None:
            require(route is not None and arrival <= number(dispatched) < end, "dispatch time")
        else:
            require(route is None and finished is None, "undispatched terminal")
        if route == "real_api":
            require(kind == "online" and dispatched >= arrival + 10, "API admission rule")
            api_count += 1
            receipt = record.get("api_receipt")
            if physical:
                require(isinstance(receipt, dict), "missing real API receipt")
                require(receipt["request_id"] == rid and receipt["run_id"] == data["run_id"],
                        "API request binding")
                require(abs(receipt["start_s"] - dispatched) < 1e-6, "API start binding")
                expected_payload = hashlib.sha256(canonical(completion_payload(source, data["served_model"]))).hexdigest()
                require(receipt["payload_sha256"] == expected_payload, "API payload binding")
                if receipt["status"] == "ok":
                    proxy = record.get("proxy_receipt", {})
                    require(proxy.get("wire_request_id") == receipt["wire_request_id"]
                            and proxy.get("payload_sha256") == expected_payload
                            and proxy.get("response_sha256") == receipt["response_sha256"]
                            and proxy.get("http_status") == 200, "server/client receipt mismatch")
                    raw = proxy["response_utf8"].encode()
                    require(hashlib.sha256(raw).hexdigest() == receipt["response_sha256"], "response digest")
                    parsed = validate_response(json.loads(raw), source, data["served_model"])
                    require(parsed["output_tokens"] == receipt["output_tokens"], "usage binding")
                    require(receipt["completed_at"] == receipt["end_s"]
                            and (finished == receipt["end_s"]
                                 or finished is None and receipt["end_s"] > end), "API completion clock")
                    require(receipt["latency_s"] >= 0 and receipt["end_s"] >= dispatched,
                            "API monotonic duration")
                    require(abs(receipt["latency_s"]-(receipt["client_end_ns"]-receipt["client_start_ns"])/1e9) < 1e-8
                            and abs(receipt["latency_s"]-(receipt["end_s"]-receipt["start_s"])) < 1e-6,
                            "API latency arithmetic")
                    require(receipt["client_start_ns"] <= proxy["proxy_start_ns"]
                            <= proxy["proxy_end_ns"] <= receipt["client_end_ns"], "API clock ordering")
                    require(proxy["gpu_uuid"] in data["external_gpu_uuids"], "unexpected serving GPU")
                else:
                    require(finished is None, "failed HTTP call cannot be completed")
                    populations[kind]["errors"] += 1
            if finished is not None and finished <= end:
                api_ok += 1
                input_tokens += source["input_tokens"]
                output_tokens += source["max_output_tokens"]
                api_latencies.append(finished-dispatched)
        if finished is not None:
            require(dispatched is not None and number(finished) >= dispatched, "terminal ordering")
        c = populations[kind]
        c["arrivals"] += 1
        if finished is None or finished > end:
            c["unfinished"] += 1
        else:
            c["on_time" if finished <= deadline else "late"] += 1

    occupied, starts, stops = 0.0, 0, 0
    previous = {0: -math.inf, 1: -math.inf}
    for generation in sorted(data["generations"], key=lambda x: (x["gpu"], x["launch_s"])):
        g = generation["gpu"]
        require(type(g) is int and g in previous, "local GPU index")
        launch, shutdown, release = [number(generation[k]) for k in
            ("launch_s", "shutdown_s", "release_s")]
        ready = generation["ready_s"]
        require(previous[g] <= launch <= shutdown <= release, "generation ordering")
        require(ready is None or launch <= number(ready) <= release, "readiness outside generation")
        previous[g] = release
        occupied += max(0, min(end, release)-max(0, launch))
        starts += 0 <= launch < end
        stops += 0 <= shutdown < end
    require(occupied <= 2*end+1e-6, "local occupancy overflow")
    require(len(data["external_gpu_uuids"]) == len(set(data["external_gpu_uuids"])) == 2,
            "two external GPU identities required")
    # Both fixed provider replicas are allocated throughout each observation.
    provider = 2*end
    system_cost = .001*(occupied+provider) + .002*starts + .001*stops
    client_scenario = .001*occupied + .002*starts + .001*stops + 1e-6*input_tokens + 3e-6*output_tokens
    return dict(P1plus=all(c["arrivals"] > 0 and c["on_time"] == c["arrivals"]
                          for c in populations.values()), populations=populations,
        local_gpu_seconds=occupied, external_gpu_seconds=provider,
        total_gpu_seconds=occupied+provider, system_scenario_cost=system_cost,
        client_scenario_cost=client_scenario, api_dispatched=api_count, api_completed=api_ok,
        api_input_tokens=input_tokens, api_output_tokens=output_tokens,
        api_latency_min=min(api_latencies, default=None), api_latency_max=max(api_latencies, default=None),
        cost_scope="Primary system ledger includes fixed provider GPUs; client ledger is a separate scenario, not summed.")


def choose(predictions, candidate_ids, windows):
    require(len(predictions) == len(candidate_ids)*len(windows), "prediction coverage")
    indexed = {(p["policy_id"], p["window_id"]): p for p in predictions}
    require(set(indexed) == {(p, w) for p in candidate_ids for w in windows}, "duplicate/missing prediction")
    viable = {}
    for policy in candidate_ids:
        group = [evaluate(indexed[(policy, w)], physical=False) for w in windows]
        if all(r["P1plus"] for r in group):
            viable[policy] = sum(r["system_scenario_cost"] for r in group)/len(windows)
    best = min(viable.values(), default=None)
    return dict(selected=[p for p in candidate_ids if p in viable and abs(viable[p]-best) <= 1e-9],
                feasible_candidates=list(viable), predicted_costs=viable,
                cost_metric="system_scenario_cost", tie_tolerance=1e-9)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("record", type=Path)
    p.add_argument("--prediction", action="store_true")
    args = p.parse_args()
    print(json.dumps(evaluate(json.loads(args.record.read_text()), physical=not args.prediction), indent=2))


if __name__ == "__main__":
    main()
