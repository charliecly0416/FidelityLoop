"""Measured HTTP completions, with one bounded pool for each serving replica."""
import asyncio
import hashlib
import json
import math
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def completion_payload(row, model):
    ids = row["prompt_token_ids"]
    if (not ids or len(ids) != row["input_tokens"]
            or any(type(v) is not int or v < 0 for v in ids)
            or type(row["max_output_tokens"]) is not int or row["max_output_tokens"] <= 0):
        raise ValueError("invalid prompt or output budget")
    return dict(model=model, prompt=ids, max_tokens=row["max_output_tokens"],
                temperature=0.0, top_p=1.0, n=1, stream=False, seed=0,
                ignore_eos=True, add_special_tokens=False)


def validate_response(body, row, model):
    if not isinstance(body, dict) or body.get("model") != model:
        raise ValueError("served model differs")
    choices, usage = body.get("choices"), body.get("usage", {})
    if (not isinstance(choices, list) or len(choices) != 1
            or not isinstance(choices[0].get("text"), str)
            or choices[0].get("finish_reason") != "length"
            or type(usage.get("prompt_tokens")) is not int
            or usage["prompt_tokens"] != row["input_tokens"]
            or type(usage.get("completion_tokens")) is not int
            or usage["completion_tokens"] != row["max_output_tokens"]):
        raise ValueError("completion/usage differs from fixed-token contract")
    return dict(response_id=body.get("id"), input_tokens=usage["prompt_tokens"],
                output_tokens=usage["completion_tokens"], text=choices[0]["text"],
                finish_reason=choices[0]["finish_reason"])


class OffloadClient:
    """Use from one asyncio loop. Caller admits only when capacity is available.

    Success is timestamped after receiving and validating a real response.
    No retries, delay substitution, model fallback or automatic rerouting.
    The callback receives request_start and request_terminal receipt dictionaries.
    """
    def __init__(self, endpoints, model, *, slots=4, timeout=120.0,
                 emit=None, clock=time.monotonic_ns):
        if (not endpoints or len(set(endpoints)) != len(endpoints)
                or type(slots) is not int or slots <= 0
                or not math.isfinite(timeout) or timeout <= 0):
            raise ValueError("invalid endpoint capacity or timeout")
        for url in endpoints:
            parsed = urlparse(url)
            if (parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost")
                    or parsed.username or parsed.password or parsed.query or parsed.fragment
                    or parsed.path not in ("", "/")):
                raise ValueError("this study requires credential-free loopback endpoints")
        self.endpoints = [u.rstrip("/") for u in endpoints]
        self.model, self.slots, self.timeout = model, slots, timeout
        self.active = [0] * len(endpoints)
        self.poisoned = False
        self._turn = 0
        self.seen = set()
        self.emit, self.clock = emit or (lambda record: None), clock
        self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @property
    def available(self):
        return not self.poisoned and any(n < self.slots for n in self.active)

    def _exchange(self, index, rid, payload):
        request = urllib.request.Request(self.endpoints[index] + "/v1/completions",
            data=payload, headers={"Content-Type": "application/json",
                                  "X-FidelityLoop-Request-ID": rid})
        try:
            with self._opener.open(request, timeout=self.timeout) as response:
                raw = response.read(16 * 1024 * 1024 + 1)
                if len(raw) > 16 * 1024 * 1024:
                    raise ValueError("oversized completion")
                return response.status, raw
        except urllib.error.HTTPError as error:
            return error.code, error.read(65536)

    async def generate(self, row, *, run_id, origin_ns):
        if row["job_type"] != "online":
            raise ValueError("offline jobs cannot offload")
        rid = run_id + ":" + row["request_id"]
        if rid in self.seen or not self.available:
            raise ValueError("duplicate request or endpoint capacity exceeded")
        payload = canonical(completion_payload(row, self.model))
        index = min((i for i, n in enumerate(self.active) if n < self.slots),
                    key=lambda i: (self.active[i], (i-self._turn) % len(self.active)))
        self._turn = (index+1) % len(self.active)
        self.active[index] += 1
        self.seen.add(rid)
        begin = self.clock()
        start = dict(kind="request_start", run_id=run_id,
            request_id=row["request_id"], wire_request_id=rid, endpoint=index,
            client_start_ns=begin, start_s=(begin-origin_ns)/1e9,
            payload_sha256=hashlib.sha256(payload).hexdigest())
        result = dict(start, kind="request_terminal", status="error", http_status=None,
                      completed_at=None, input_tokens=None, output_tokens=None)
        try:
            self.emit(start)
            status, raw = await asyncio.to_thread(self._exchange, index, rid, payload)
            result.update(http_status=status, response_sha256=hashlib.sha256(raw).hexdigest())
            if status != 200:
                raise ValueError("HTTP status " + str(status))
            result.update(validate_response(json.loads(raw), row, self.model))
            result["status"] = "ok"
        except asyncio.CancelledError:
            self.poisoned = True
            result["status"] = "cancelled"
            result["error"] = "client cancelled; server drain must be verified separately"
            raise
        except Exception as error:
            # A failed exchange may leave generation active on the provider.
            # Stop new admissions until the caller proves provider drain.
            self.poisoned = True
            result["error"] = type(error).__name__ + ": " + str(error)[:300]
        finally:
            end = self.clock()
            result.update(client_end_ns=end, end_s=(end-origin_ns)/1e9,
                          latency_s=(end-begin)/1e9)
            if result["status"] == "ok":
                result["completed_at"] = result["end_s"]
            self.active[index] -= 1
            self.emit(dict(result))
        return result
