"""Score the fixed paired route probe with all failures in its denominator."""
import argparse
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re


def numeric(value):
    value = value.strip().replace(",", "")
    if not re.fullmatch(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)", value):
        return None
    try:
        return Decimal(value)
    except InvalidOperation:
        return None


def answer(text):
    if "####" not in text:
        return None
    tail = text.rsplit("####", 1)[1].strip().lstrip("$")
    match = re.fullmatch(r"([+-]?(?:[0-9][0-9,]*(?:\.[0-9]+)?|\.[0-9]+))(?:[.]|[$])?\s*", tail)
    return numeric(match.group(1)) if match else None


def score(records, dataset):
    gold = {row["id"]: numeric(row["reference_answer"]) for row in dataset}
    if len(gold) != len(dataset) or any(v is None for v in gold.values()):
        raise ValueError("invalid probe dataset")
    by = {(row["id"], row["route"]): row for row in records}
    expected = {(ident, route) for ident in gold for route in ("local", "external")}
    if len(by) != len(records) or set(by) != expected:
        raise ValueError("missing, duplicate or extra route-probe result")
    flags = {}
    totals = {}
    for route in ("local", "external"):
        good = errors = truncated = unparsed = 0
        for ident, reference in gold.items():
            row = by[ident, route]
            text = row.get("response_text", "")
            if not isinstance(text, str):
                raise ValueError("response text must be a string")
            if row.get("response_sha256") != hashlib.sha256(text.encode()).hexdigest():
                raise ValueError("response digest mismatch")
            ok = row.get("status") == "ok"
            predicted = answer(text) if ok else None
            correct = ok and predicted is not None and predicted == reference
            flags[ident, route] = correct
            good += correct
            errors += not ok
            truncated += row.get("finish_reason") == "length"
            unparsed += ok and predicted is None
        totals[route] = dict(questions=len(gold), correct=good, errors=errors,
                             truncated=truncated, unparsed=unparsed)
    totals["paired"] = dict(both_correct=sum(flags[i,"local"] and flags[i,"external"] for i in gold),
        only_local_correct=sum(flags[i,"local"] and not flags[i,"external"] for i in gold),
        only_external_correct=sum(flags[i,"external"] and not flags[i,"local"] for i in gold),
        both_incorrect=sum(not flags[i,"local"] and not flags[i,"external"] for i in gold))
    totals["scope"] = "Descriptive 64-question paired task probe, not a statistical equivalence test."
    return totals


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("records", type=Path)
    parser.add_argument("--dataset", type=Path, default=Path(__file__).resolve().parents[1]/"quality/gsm8k64.jsonl")
    args = parser.parse_args()
    read = lambda p: [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
    print(json.dumps(score(read(args.records), read(args.dataset)), indent=2))


if __name__ == "__main__":
    main()
