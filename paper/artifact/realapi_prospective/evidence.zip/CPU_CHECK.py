"""Offline CPU-only verification: no torch, CUDA, network or external paths."""
import json
from pathlib import Path
from toolkit.audit import evaluate, choose
from toolkit.integrity import verify
from toolkit.score_quality import score
root=Path(__file__).resolve().parent
verify(root)
read=lambda p:json.loads(p.read_text())
count=0
for path in sorted((root/'records').glob('*.json')):
    item=read(path)
    assert evaluate(item['record'],physical=True)==item['expected'],path.name
    count+=1
design=read(root/'design.json')
for predictor,expected in read(root/'selection.json').items():
    predictions=[read(p) for p in sorted((root/'predictions'/predictor).glob('*.json'))]
    assert choose(predictions,design['candidate_policy_ids'],design['window_ids'])==expected
dataset=[json.loads(s) for s in (root/'quality_dataset.jsonl').read_text().splitlines()]
records=[json.loads(s) for s in (root/'quality_results.jsonl').read_text().splitlines()]
assert score(records,dataset)==read(root/'QUALITY_REPORT.json')
assert count==read(root/'COMPLETENESS.json')['completed_cells']
print(json.dumps({'status':'PASS','physical_records':count,'candidate_predictions':64,'quality_responses':len(records),'offline_cpu_only':True}))
